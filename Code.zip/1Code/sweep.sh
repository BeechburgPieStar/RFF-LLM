#!/bin/bash
# =============================================================================
# sweep.sh — 双卡并行扫超参
#
# 跑 2 数据集 × 4 折 × 8 llm_hidden = 64 次 stage-3 实验
# ManySig 占 GPU 0, ManyRx 占 GPU 1, 两数据集后台并行
# stage 1+2 在每个 (dataset, test_round) 组合下只跑一次
#
# 用法:
#   bash sweep.sh                  # 跑完整 sweep
#   bash sweep.sh > sweep.out 2>&1 # 后台:  nohup bash sweep.sh > sweep.out 2>&1 &
#
# 输出:
#   logs/<dataset>_round<r>_lh<h>.log   每次 stage-3 一份日志
#   logs/<dataset>_round<r>_prep.log    每次 stage 1+2 一份日志
#   results.csv                         所有结果一行一条
#   results.xlsx                        sweep_to_excel.py 生成的二维透视表
# =============================================================================

set -u  # 引用未定义变量直接报错; 不用 -e, 单个实验失败不中断后续

# ---- 扫描空间 ----
ROUNDS=(0 1 2 3)
LLM_HIDDENS=(2 4 8 16 32 64 128 256)

# ---- 路径 ----
LOG_DIR="logs"
RESULTS_CSV="results.csv"
mkdir -p "$LOG_DIR"

# ---- 初始化 csv (覆盖旧文件) ----
echo "dataset,test_round,llm_hidden,test_acc,status,log_path" > "$RESULTS_CSV"

# -----------------------------------------------------------------------------
# 单个数据集的串行 sweep (整段在后台 & 跑, 给两数据集分别拉起)
# 参数: $1 = dataset_name, $2 = gpu_id
# -----------------------------------------------------------------------------
run_one_dataset() {
    local DATASET=$1
    local GPU=$2

    for R in "${ROUNDS[@]}"; do
        local TAG="${DATASET}_round${R}"
        local PREP_LOG="${LOG_DIR}/${TAG}_prep.log"

        echo "[$DATASET GPU$GPU] === round $R: stage 1+2 ===" | tee -a "$PREP_LOG"

        # stage 1: 训 VQ-VAE (已存在会自动跳过)
        python run_all.py --gpu "$GPU" --stage 1 \
            --dataset_name "$DATASET" --test_round "$R" \
            >> "$PREP_LOG" 2>&1

        # stage 2: 预计算 ctx (已存在会自动跳过)
        python run_all.py --gpu "$GPU" --stage 2 \
            --dataset_name "$DATASET" --test_round "$R" \
            >> "$PREP_LOG" 2>&1

        # stage 3: 扫 llm_hidden
        for H in "${LLM_HIDDENS[@]}"; do
            local LOG="${LOG_DIR}/${TAG}_lh${H}.log"
            echo "[$DATASET GPU$GPU] === round $R, llm_hidden $H ===" > "$LOG"

            python run_all.py --gpu "$GPU" --stage 3 \
                --dataset_name "$DATASET" --test_round "$R" --llm_hidden "$H" \
                >> "$LOG" 2>&1

            local STATUS=$?

            # 从日志里提取 "Test Accuracy: X.XXXX" 最后一行
            local ACC
            ACC=$(grep -E "^Test Accuracy:" "$LOG" | tail -1 | awk '{print $3}')
            if [[ -z "$ACC" ]]; then
                ACC="NA"
                local FLAG="FAILED"
            elif [[ $STATUS -ne 0 ]]; then
                local FLAG="ERR_$STATUS"
            else
                local FLAG="OK"
            fi

            # 用 flock 防止两数据集并发写 csv 撞行 (--nb 失败则直接退避, 不阻塞)
            (
                flock -x 200
                echo "${DATASET},${R},${H},${ACC},${FLAG},${LOG}" >> "$RESULTS_CSV"
            ) 200>"${RESULTS_CSV}.lock"

            echo "[$DATASET GPU$GPU] round $R lh $H -> acc=$ACC ($FLAG)"
        done
    done

    echo "[$DATASET GPU$GPU] === DONE ==="
}

# -----------------------------------------------------------------------------
# 两数据集并行
# -----------------------------------------------------------------------------
echo "Sweep started at $(date)"
echo "Total experiments: 2 datasets x 4 rounds x ${#LLM_HIDDENS[@]} llm_hidden = $((2 * 4 * ${#LLM_HIDDENS[@]}))"
echo

run_one_dataset ManySig 0 &
PID_A=$!
run_one_dataset ManyRx 1 &
PID_B=$!

wait $PID_A
wait $PID_B

rm -f "${RESULTS_CSV}.lock"

echo
echo "Sweep finished at $(date)"
echo "Results CSV: $RESULTS_CSV"
echo
echo "Generating excel..."
python sweep_to_excel.py "$RESULTS_CSV" results.xlsx
echo "Done. Open results.xlsx"