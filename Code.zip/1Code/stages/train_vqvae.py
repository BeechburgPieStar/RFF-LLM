# -*- coding: utf-8 -*-
"""
Stage 1: VQ-VAE 预训练 (跨接收机协议: 只用训练接收机 + 训练 date).

对外接口:
    run(cfg) -> Path     # 返回保存的 ckpt 路径

也可独立运行:
    python -m stages.train_vqvae
"""
import os
import random
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau
from sklearn.model_selection import train_test_split

from config import Config
from utils.load_data import load_single_dataset
from backbones.signal_tokenizer import SignalTokenizer


# ---------------------------------------------------------------------------
def _setup_seed(seed: int):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _split_receivers(all_num: int, all_test_round: int, test_round: int):
    if not (0 <= test_round < all_test_round):
        raise ValueError(f"test_round {test_round} not in [0, {all_test_round - 1}]")
    if all_num % all_test_round != 0:
        raise ValueError(f"rx_num {all_num} not divisible by rounds {all_test_round}")
    receivers = list(range(all_num))
    per = all_num // all_test_round
    s = test_round * per
    e = all_num if test_round == all_test_round - 1 else s + per
    test = receivers[s:e]
    train = [r for r in receivers if r not in test]
    return train, test


def _prepare_dataset(cfg: Config, rx_indexes, date_indexes):
    """VQ-VAE 无监督, 标签收了不用, 只为复用 load_single_dataset 接口."""
    if len(rx_indexes) == 0 or len(date_indexes) == 0:
        raise ValueError("rx_indexes / date_indexes 不能为空")

    x_all, y_all = [], []
    for rx_index in rx_indexes:
        for date_index in date_indexes:
            x, y = load_single_dataset(
                cfg.data.dataset_name, rx_index, date_index, cfg.tx_num,
                is_eq='non_equalized', dataset_root=cfg.paths.dataset_root,
            )
            x_all.append(x)
            y_all.append(y)
    x_all = np.concatenate(x_all, axis=0)
    y_all = np.concatenate(y_all, axis=0)

    indices = np.arange(len(y_all))
    train_idx, val_idx = train_test_split(
        indices, test_size=0.3, random_state=cfg.data.seed,
        stratify=y_all if len(np.unique(y_all)) > 1 else None,
    )
    return x_all[train_idx], x_all[val_idx]


# ---------------------------------------------------------------------------
def _train_epoch(model, loader, optimizer, epoch, device, grad_clip,
                 restart_every, warmup_no_restart, global_step_ref):
    model.train()
    sum_recon = sum_commit = sum_n = 0.0
    sum_perp = sum_util = 0.0
    n_batch = 0

    for (data,) in loader:
        data = data.to(device, non_blocking=True).float()
        optimizer.zero_grad(set_to_none=True)
        out = model(data)
        out["loss"].backward()
        if grad_clip is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        optimizer.step()

        bs = data.size(0)
        sum_recon += out["recon_loss"].item() * bs
        sum_commit += out["commit_loss"].item() * bs
        sum_n += bs
        sum_perp += out["perplexity"]
        sum_util += out["codebook_util"]
        n_batch += 1

        global_step_ref[0] += 1
        if (restart_every > 0
                and global_step_ref[0] > warmup_no_restart
                and global_step_ref[0] % restart_every == 0):
            n_dead = model.restart_dead_codes(data)
            if n_dead > 0:
                print(f"  [step {global_step_ref[0]}] restarted {n_dead} dead codes")

    avg_recon = sum_recon / max(sum_n, 1)
    avg_commit = sum_commit / max(sum_n, 1)
    avg_perp = sum_perp / max(n_batch, 1)
    avg_util = sum_util / max(n_batch, 1)
    lr = optimizer.param_groups[0]['lr']
    print(f"Train Epoch: {epoch}\t"
          f"Recon: {avg_recon:.6f}, Commit: {avg_commit:.6f}, "
          f"Perp: {avg_perp:.1f}, Util: {avg_util*100:.1f}%, LR: {lr:.2e}")
    return avg_recon


@torch.no_grad()
def _eval_epoch(model, loader, epoch, device):
    model.eval()
    sum_recon = sum_commit = sum_n = 0.0
    sum_perp = sum_util = 0.0
    n_batch = 0
    for (data,) in loader:
        data = data.to(device, non_blocking=True).float()
        out = model(data)
        bs = data.size(0)
        sum_recon += out["recon_loss"].item() * bs
        sum_commit += out["commit_loss"].item() * bs
        sum_n += bs
        sum_perp += out["perplexity"]
        sum_util += out["codebook_util"]
        n_batch += 1

    avg_recon = sum_recon / max(sum_n, 1)
    avg_commit = sum_commit / max(sum_n, 1)
    avg_perp = sum_perp / max(n_batch, 1)
    avg_util = sum_util / max(n_batch, 1)
    print(f"\nValidation: Recon: {avg_recon:.6f}, Commit: {avg_commit:.6f}, "
          f"Perp: {avg_perp:.1f}, Util: {avg_util*100:.1f}%\n")
    return avg_recon


# ---------------------------------------------------------------------------
def run(cfg: Config) -> Path:
    """跑 stage 1 训练, 返回 ckpt 路径."""
    print("\n" + "#" * 70)
    print("# Stage 1: Train SignalTokenizer (VQ-VAE)")
    print("#" * 70)
    _setup_seed(cfg.data.seed)
    cfg.ensure_dirs()

    save_path = cfg.vqvae_ckpt_path
    if save_path.exists():
        print(f"[Skip] VQ-VAE ckpt 已存在: {save_path}")
        return save_path

    rx_train, rx_test = _split_receivers(cfg.rx_num, cfg.data.all_test_round, cfg.data.test_round)
    print(f"Train receivers: {rx_train}")
    print(f"Test  receivers: {rx_test}  (not used for VQ-VAE)")

    x_train, x_val = _prepare_dataset(cfg, rx_train, cfg.data.train_date)
    print(f"VQ-VAE train: {x_train.shape}, val: {x_val.shape}")

    x_train_t = torch.tensor(x_train, dtype=torch.float32)
    x_val_t = torch.tensor(x_val, dtype=torch.float32)
    train_loader = DataLoader(TensorDataset(x_train_t),
                              batch_size=cfg.vqvae.batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(x_val_t),
                            batch_size=cfg.vqvae.batch_size, shuffle=False)

    signal_len = x_train.shape[-1]
    model = SignalTokenizer(
        signal_len=signal_len,
        patch_size=cfg.vqvae.patch_size,
        d_code=cfg.vqvae.d_code,
        codebook_size=cfg.vqvae.codebook_size,
        n_resblocks=cfg.vqvae.n_resblocks,
        commitment_cost=cfg.vqvae.commitment_cost,
        ema_decay=cfg.vqvae.ema_decay,
    )
    n_params = sum(p.numel() for p in model.parameters())
    print(f"[Model] SignalTokenizer params: {n_params:,}")
    print(f"[CKPT ] {save_path}")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.vqvae.lr,
                                 weight_decay=cfg.vqvae.wd)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5,
                                  patience=cfg.vqvae.scheduler_patience,
                                  min_lr=cfg.vqvae.min_lr)

    best_val = float('inf')
    no_improve = 0
    global_step = [0]

    for epoch in range(1, cfg.vqvae.epochs + 1):
        _train_epoch(model, train_loader, optimizer, epoch, device,
                     cfg.vqvae.grad_clip, cfg.vqvae.restart_every,
                     cfg.vqvae.warmup_steps_no_restart, global_step)
        val_recon = _eval_epoch(model, val_loader, epoch, device)
        scheduler.step(val_recon)

        if val_recon < best_val:
            print(f"Validation recon improved {best_val:.6f} -> {val_recon:.6f}. Saving...")
            best_val = val_recon
            torch.save(model.state_dict(), save_path)
            no_improve = 0
        else:
            no_improve += 1
            print(f"No improvement for {no_improve} epoch(s).")

        if no_improve >= cfg.vqvae.patience_early_stop:
            print(f"Early stopping at epoch {epoch}.")
            break
        print("-" * 50)

    return save_path


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from config import parse_runtime_args
    cfg = parse_runtime_args(Config())
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.runtime.gpu
    print(cfg.describe())
    run(cfg)
