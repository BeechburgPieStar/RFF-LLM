# -*- coding: utf-8 -*-
"""
Stage 3 [Ablation]: LLM-only 单模态分类器训练.

- 信号分支被完全移除, 只使用预计算的 LLM ctx_vec.
- ctx_vec = 真实 LLM 特征 (验证 LLM 分支独立分类能力).
- ckpt 自动追加 "_llmonly" 后缀, 与融合模型并存.

对外接口:
    run(cfg) -> Path     # 返回 ckpt 路径

也可独立运行:
    python -m stages.train_fusion_llmonly
"""
import os
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau

from config import Config
from backbones.llm_only_classifier import LLMOnlyClassifier


# ---------------------------------------------------------------------------
def _setup_seed(seed: int):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _load_cache(npz_path: Path):
    """只取 y 和 ctx_vec; 不再加载 x (信号), 节省内存."""
    if not npz_path.exists():
        raise FileNotFoundError(
            f"Cache 不存在: {npz_path}\n"
            f"请先跑 stage 2 (python -m stages.precompute_ctx)"
        )
    data = np.load(npz_path)
    return {
        "y":       data["y"].astype(np.int64),
        "ctx_vec": data["ctx_vec"].astype(np.float32),
    }


def _llmonly_ckpt_path(orig_path: Path) -> Path:
    """在 ckpt 文件名 (stem) 后追加 '_llmonly' 标记.
    e.g. fusion_best.pt -> fusion_best_llmonly.pt
    """
    return orig_path.with_name(f"{orig_path.stem}_llmonly{orig_path.suffix}")


def _make_loader(d: dict, batch_size: int, shuffle: bool):
    ds = TensorDataset(
        torch.from_numpy(d["ctx_vec"]),
        torch.from_numpy(d["y"]),
    )
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=False)


def _to_device(batch, device):
    ctx, y = batch
    return (ctx.to(device, non_blocking=True).float(),
            y.to(device, non_blocking=True).long())


# ---------------------------------------------------------------------------
def _train_epoch(model, criterion, loader, optimizer, epoch, device, grad_clip):
    model.train()
    total_loss = correct = total = 0
    for batch in loader:
        ctx, y = _to_device(batch, device)
        optimizer.zero_grad(set_to_none=True)
        _, logits = model(ctx)
        loss = criterion(logits, y)
        loss.backward()
        if grad_clip is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        optimizer.step()
        bs = ctx.size(0)
        total_loss += loss.item() * bs
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += bs
    avg_loss = total_loss / max(total, 1)
    acc = 100.0 * correct / max(total, 1)
    lr = optimizer.param_groups[0]['lr']
    print(f"Train Epoch: {epoch}\tLoss: {avg_loss:.6f}, "
          f"Acc: {correct}/{total} ({acc:.2f}%), LR: {lr:.2e}")
    return avg_loss, acc


@torch.no_grad()
def _eval_epoch(model, criterion, loader, epoch, device):
    model.eval()
    total_loss = correct = total = 0
    for batch in loader:
        ctx, y = _to_device(batch, device)
        _, logits = model(ctx)
        loss = criterion(logits, y)
        bs = ctx.size(0)
        total_loss += loss.item() * bs
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += bs
    avg_loss = total_loss / max(total, 1)
    acc = 100.0 * correct / max(total, 1)
    print(f"\nValidation: Loss: {avg_loss:.4f}, "
          f"Acc: {correct}/{total} ({acc:.2f}%)\n")
    return avg_loss, acc


@torch.no_grad()
def _test_epoch(model, loader, device):
    model.eval()
    correct = total = 0
    for batch in loader:
        ctx, y = _to_device(batch, device)
        _, logits = model(ctx)
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += ctx.size(0)
    acc = correct / max(total, 1)
    print(f"Test Accuracy: {acc:.4f}")
    return acc


# ---------------------------------------------------------------------------
def _build_model(cfg: Config, d_ctx: int) -> LLMOnlyClassifier:
    return LLMOnlyClassifier(
        d_ctx=d_ctx,
        num_classes=cfg.tx_num,
        d_fuse=cfg.fusion.d_fuse,
        llm_hidden=cfg.fusion.llm_hidden,
        dropout=cfg.fusion.dropout,
    )


# ---------------------------------------------------------------------------
def run(cfg: Config) -> Path:
    """跑 stage 3 LLM-only 训练 (+测试), 返回 ckpt 路径."""
    print("\n" + "#" * 70)
    print("# Stage 3: Train LLMOnlyClassifier  [LLM-ONLY ABLATION]")
    print("#" * 70)
    _setup_seed(cfg.data.seed)
    cfg.ensure_dirs()

    save_path = _llmonly_ckpt_path(cfg.mm_ckpt_path)
    print(f"[CKPT ] {save_path}  (llm-only ablation)")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # ---- 训练 ----
    if cfg.runtime.code_state in ("only_train", "train_test"):
        d_tr = _load_cache(cfg.cache_paths["train"])
        d_val = _load_cache(cfg.cache_paths["val"])
        print(f"Train: ctx={d_tr['ctx_vec'].shape}, y={d_tr['y'].shape}")
        print(f"Val  : ctx={d_val['ctx_vec'].shape}, y={d_val['y'].shape}")
        d_ctx = d_tr["ctx_vec"].shape[1]

        train_loader = _make_loader(d_tr, cfg.fusion.batch_size, shuffle=True)
        val_loader = _make_loader(d_val, cfg.fusion.batch_size, shuffle=False)

        model = _build_model(cfg, d_ctx=d_ctx).to(device)
        n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"[Model] LLMOnlyClassifier trainable params: {n_train:,}")

        optimizer = torch.optim.Adam(model.parameters(), lr=cfg.fusion.lr,
                                     weight_decay=cfg.fusion.wd)
        criterion = nn.CrossEntropyLoss().to(device)
        scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.1,
                                      patience=cfg.fusion.scheduler_patience,
                                      min_lr=cfg.fusion.min_lr)

        best_val = float('inf')
        no_improve = 0
        for epoch in range(1, cfg.fusion.epochs + 1):
            _train_epoch(model, criterion, train_loader, optimizer, epoch, device,
                         cfg.fusion.grad_clip)
            val_loss, _ = _eval_epoch(model, criterion, val_loader, epoch, device)
            scheduler.step(val_loss)
            if val_loss < best_val:
                print(f"Validation loss improved {best_val:.6f} -> {val_loss:.6f}. Saving...")
                best_val = val_loss
                torch.save(model.state_dict(), save_path)
                no_improve = 0
            else:
                no_improve += 1
                print(f"No improvement for {no_improve} epoch(s).")
            if no_improve >= cfg.fusion.patience_early_stop:
                print(f"Early stopping at epoch {epoch}.")
                break
            print("-" * 50)

    # ---- 测试 ----
    if cfg.runtime.code_state in ("only_test", "train_test"):
        if not save_path.exists():
            raise FileNotFoundError(f"Checkpoint 不存在: {save_path}")
        d_te = _load_cache(cfg.cache_paths["test"])
        print(f"Test : ctx={d_te['ctx_vec'].shape}, y={d_te['y'].shape}")
        d_ctx = d_te["ctx_vec"].shape[1]

        model = _build_model(cfg, d_ctx=d_ctx)
        state = torch.load(save_path, map_location="cpu")
        model.load_state_dict(state)
        model = model.to(device)

        test_loader = _make_loader(d_te, batch_size=128, shuffle=False)
        _test_epoch(model, test_loader, device)

    return save_path


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from config import parse_runtime_args
    cfg = parse_runtime_args(Config())
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.runtime.gpu
    print(cfg.describe())
    run(cfg)
