# -*- coding: utf-8 -*-
"""
Stage 2: 离线预计算 ctx_vec, 存成 .npz 缓存供训练加载.

每个 .npz 含:
    x:       (N, 2, L)  float32
    y:       (N,)       int64   Tx 标签
    rx:      (N,)       int64   全局 rx_id
    ctx_vec: (N, d_llm) float32 LLM 上下文向量

对外接口:
    run(cfg) -> dict[str, Path]    # 三个 split 的 npz 路径

也可独立运行:
    python -m stages.precompute_ctx
"""
import os
import random
from pathlib import Path
from typing import Dict

import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split

from config import Config
from utils.load_data import load_single_dataset
from utils.context_encoder import ContextEncoder
from backbones.signal_tokenizer import SignalTokenizer


# ---------------------------------------------------------------------------
def _setup_seed(seed: int):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _split_receivers(all_num: int, all_test_round: int, test_round: int):
    receivers = list(range(all_num))
    per = all_num // all_test_round
    s = test_round * per
    e = all_num if test_round == all_test_round - 1 else s + per
    test = receivers[s:e]
    train = [r for r in receivers if r not in test]
    return train, test


def _collect_with_rxid(cfg: Config, rx_indexes, date_indexes):
    """收集数据, 同时记录每条样本的全局 rx_id."""
    x_all, y_all, r_all = [], [], []
    for rx_index in rx_indexes:
        for date_index in date_indexes:
            x, y = load_single_dataset(
                cfg.data.dataset_name, rx_index, date_index, cfg.tx_num,
                is_eq='non_equalized', dataset_root=cfg.paths.dataset_root,
            )
            x_all.append(x)
            y_all.append(y)
            r_all.append(np.full(len(y), rx_index, dtype=np.int64))
    return (np.concatenate(x_all, axis=0),
            np.concatenate(y_all, axis=0),
            np.concatenate(r_all, axis=0))


# ---------------------------------------------------------------------------
def _encode_ctx(encoder: ContextEncoder, x, r, batch_size: int, device: str):
    ds = TensorDataset(
        torch.as_tensor(x, dtype=torch.float32),
        torch.as_tensor(r, dtype=torch.long),
    )
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, drop_last=False)

    encoder = encoder.to(device)
    encoder.eval()

    out_chunks = []
    n_done, n_total = 0, len(ds)
    for xb, rb in loader:
        xb = xb.to(device, non_blocking=True).float()
        rb = rb.to(device, non_blocking=True).long()
        ctx = encoder(xb, rb)                              # (b, d_llm)
        out_chunks.append(ctx.detach().float().cpu().numpy())
        n_done += xb.size(0)
        if n_done % (batch_size * 10) == 0 or n_done == n_total:
            print(f"  {n_done}/{n_total}")
    return np.concatenate(out_chunks, axis=0)


def _save_split(cache_path: Path, x, y, r, ctx_vec):
    np.savez_compressed(cache_path, x=x, y=y, rx=r, ctx_vec=ctx_vec)
    print(f"  -> {cache_path}  (ctx_vec {ctx_vec.shape}, x {x.shape})")


# ---------------------------------------------------------------------------
def run(cfg: Config) -> Dict[str, Path]:
    """跑 stage 2 预计算, 返回三个 split 的 npz 路径."""
    print("\n" + "#" * 70)
    print("# Stage 2: Precompute ctx_vec")
    print("#" * 70)
    _setup_seed(cfg.data.seed)
    cfg.ensure_dirs()

    paths = cfg.cache_paths
    for k, p in paths.items():
        print(f"  {k}: {p}")

    # 全部已存在且不强制重算 -> 直接退出
    if (not cfg.runtime.overwrite_cache) and all(p.exists() for p in paths.values()):
        print("[Skip] 三个缓存文件都已存在. 用 --overwrite_cache 强制重算.")
        return paths

    # 1) 收集训练/验证
    rx_train, rx_test = _split_receivers(cfg.rx_num, cfg.data.all_test_round, cfg.data.test_round)
    print(f"Train rx: {rx_train}")
    print(f"Test  rx: {rx_test}")

    x_tv, y_tv, r_tv = _collect_with_rxid(cfg, rx_train, cfg.data.train_date)
    indices = np.arange(len(y_tv))
    tr_idx, val_idx = train_test_split(
        indices, test_size=0.3, random_state=cfg.data.seed,
        stratify=y_tv if len(np.unique(y_tv)) > 1 else None,
    )
    x_tr, y_tr, r_tr = x_tv[tr_idx], y_tv[tr_idx], r_tv[tr_idx]
    x_val, y_val, r_val = x_tv[val_idx], y_tv[val_idx], r_tv[val_idx]
    print(f"Train: {x_tr.shape}, Val: {x_val.shape}")

    # 2) 测试集
    test_dates = cfg.test_dates
    print(f"Test dates: {test_dates}")
    x_te, y_te, r_te = _collect_with_rxid(cfg, rx_test, test_dates)
    print(f"Test: {x_te.shape}")

    # 3) 构造 SignalTokenizer + ContextEncoder
    signal_len = x_tr.shape[-1]
    tokenizer_model = SignalTokenizer(
        signal_len=signal_len,
        patch_size=cfg.vqvae.patch_size,
        d_code=cfg.vqvae.d_code,
        codebook_size=cfg.vqvae.codebook_size,
        n_resblocks=cfg.vqvae.n_resblocks,
    )
    if not cfg.vqvae_ckpt_path.exists():
        raise FileNotFoundError(
            f"VQ-VAE ckpt 不存在: {cfg.vqvae_ckpt_path}\n"
            f"请先跑 stage 1 (python -m stages.train_vqvae)"
        )
    state = torch.load(cfg.vqvae_ckpt_path, map_location="cpu")
    if "model" in state:
        state = state["model"]
    tokenizer_model.load_state_dict(state)
    print(f"[VQ-VAE] loaded from {cfg.vqvae_ckpt_path}")

    dtype_map = {"float32": torch.float32, "float16": torch.float16,
                 "bfloat16": torch.bfloat16}
    encoder = ContextEncoder(
        tokenizer_model=tokenizer_model,
        llm_path=cfg.llm.llm_path,
        num_rx=cfg.rx_num,
        codebook_size=cfg.vqvae.codebook_size,
        vq_qwen_base_offset=cfg.llm.vq_qwen_base_offset,
        pool=cfg.llm.pool,
        torch_dtype=dtype_map[cfg.llm.llm_dtype],
    )
    print(f"[ContextEncoder] d_llm = {encoder.d_llm}, prefix_len = {encoder.prefix_len}")

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # 4) 三个 split 分别预计算
    for split_name, (xs, ys, rs) in [
        ("train", (x_tr, y_tr, r_tr)),
        ("val",   (x_val, y_val, r_val)),
        ("test",  (x_te, y_te, r_te)),
    ]:
        if paths[split_name].exists() and not cfg.runtime.overwrite_cache:
            print(f"[Skip {split_name}] cache exists.")
            continue
        print(f"\n--- Encoding {split_name} ({len(xs)} samples) ---")
        ctx_vec = _encode_ctx(encoder, xs, rs, cfg.llm.ctx_batch_size, device)
        _save_split(paths[split_name], xs, ys, rs, ctx_vec)

    print("\n[Done] all caches written.")
    return paths


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from config import parse_runtime_args
    cfg = parse_runtime_args(Config())
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.runtime.gpu
    print(cfg.describe())
    run(cfg)
