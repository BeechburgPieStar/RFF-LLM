# -*- coding: utf-8 -*-
"""
Stage 3: 多模态分类器训练 (PatchNet 信号分支 + LLM ctx_vec 分支).

[Ablation 版本] ctx_vec 被替换为高斯噪声 (匹配原始 per-dim 均值/方差).
- 保持 shape / dtype 不变, 下游模型无需改动.
- ckpt 自动追加 "_noise" 后缀, 避免覆盖正常训练的模型.

对外接口:
    run(cfg) -> Path     # 返回 ckpt 路径

也可独立运行:
    python -m stages.train_fusion
"""
import os
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau

from config import Config
from backbones.fusion_classifier import FusionClassifier


# ---------------------------------------------------------------------------
def _setup_seed(seed: int):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _load_cache(npz_path: Path):
    if not npz_path.exists():
        raise FileNotFoundError(
            f"Cache 不存在: {npz_path}\n"
            f"请先跑 stage 2 (python -m stages.precompute_ctx)"
        )
    data = np.load(npz_path)
    return {
        "x":       data["x"].astype(np.float32),
        "y":       data["y"].astype(np.int64),
        "rx":      data["rx"].astype(np.int64),
        "ctx_vec": data["ctx_vec"].astype(np.float32),
    }


def _replace_ctx_with_noise(d: dict, seed: int, split_name: str) -> dict:
    """硬替换: 用匹配原 ctx_vec per-dim 均值/方差的高斯噪声替换 ctx_vec.

    - 保持 shape / dtype 不变.
    - 使用独立 RNG (np.random.default_rng), 不污染全局随机状态.
    - train/val/test 用不同 seed offset, 三个 split 拿到不同但确定的噪声.
    """
    orig = d["ctx_vec"]
    shape = orig.shape

    split_offset = {"train": 0, "val": 1, "test": 2}.get(split_name, 99)
    rng = np.random.default_rng(seed + split_offset)

    mu = orig.mean(axis=0, keepdims=True)
    sigma = orig.std(axis=0, keepdims=True) + 1e-8
    new_ctx = rng.standard_normal(size=shape).astype(np.float32) * sigma + mu

    print(f"[CTX-NOISE] [{split_name}] shape={shape}, "
          f"mu_avg={mu.mean():.4f}, sigma_avg={sigma.mean():.4f}")

    d = dict(d)  # 浅拷贝, 不污染调用方
    d["ctx_vec"] = new_ctx
    return d


def _noise_ckpt_path(orig_path: Path) -> Path:
    """在 ckpt 文件名 (stem) 后追加 '_noise' 标记.
    e.g. fusion_best.pt -> fusion_best_noise.pt
    """
    return orig_path.with_name(f"{orig_path.stem}_noise{orig_path.suffix}")


def _make_loader(d: dict, batch_size: int, shuffle: bool):
    ds = TensorDataset(
        torch.from_numpy(d["x"]),
        torch.from_numpy(d["y"]),
        torch.from_numpy(d["ctx_vec"]),
    )
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=False)


def _to_device(batch, device):
    x, y, ctx = batch
    return (x.to(device, non_blocking=True).float(),
            y.to(device, non_blocking=True).long(),
            ctx.to(device, non_blocking=True).float())


# ---------------------------------------------------------------------------
def _train_epoch(model, criterion, loader, optimizer, epoch, device, grad_clip):
    model.train()
    total_loss = correct = total = 0
    for batch in loader:
        x, y, ctx = _to_device(batch, device)
        optimizer.zero_grad(set_to_none=True)
        _, logits = model(x, ctx)
        loss = criterion(logits, y)
        loss.backward()
        if grad_clip is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        optimizer.step()
        bs = x.size(0)
        total_loss += loss.item() * bs
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += bs
    avg_loss = total_loss / max(total, 1)
    acc = 100.0 * correct / max(total, 1)
    lr = optimizer.param_groups[0]['lr']
    print(f"Train Epoch: {epoch}\tLoss: {avg_loss:.6f}, "
          f"Acc: {correct}/{total} ({acc:.2f}%), LR: {lr:.2e}")
    return avg_loss, acc


@torch.no_grad()
def _eval_epoch(model, criterion, loader, epoch, device):
    model.eval()
    total_loss = correct = total = 0
    for batch in loader:
        x, y, ctx = _to_device(batch, device)
        _, logits = model(x, ctx)
        loss = criterion(logits, y)
        bs = x.size(0)
        total_loss += loss.item() * bs
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += bs
    avg_loss = total_loss / max(total, 1)
    acc = 100.0 * correct / max(total, 1)
    print(f"\nValidation: Loss: {avg_loss:.4f}, "
          f"Acc: {correct}/{total} ({acc:.2f}%)\n")
    return avg_loss, acc


@torch.no_grad()
def _test_epoch(model, loader, device):
    model.eval()
    correct = total = 0
    for batch in loader:
        x, y, ctx = _to_device(batch, device)
        _, logits = model(x, ctx)
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += x.size(0)
    acc = correct / max(total, 1)
    print(f"Test Accuracy: {acc:.4f}")
    return acc


# ---------------------------------------------------------------------------
def _build_model(cfg: Config, d_ctx: int) -> FusionClassifier:
    return FusionClassifier(
        d_ctx=d_ctx,
        num_classes=cfg.tx_num,
        iq_patch_size=cfg.fusion.iq_patch_size,
        embed_dim=cfg.fusion.embed_dim,
        n_layers=cfg.fusion.n_layers,
        mlp_ratio=cfg.fusion.mlp_ratio,
        d_fuse=cfg.fusion.d_fuse,
        llm_hidden=cfg.fusion.llm_hidden,
        fusion=cfg.fusion.fusion,
        dropout=cfg.fusion.dropout,
    )


# ---------------------------------------------------------------------------
def run(cfg: Config) -> Path:
    """跑 stage 3 训练 (+测试), 返回 ckpt 路径.

    [ABLATION] ctx_vec 被硬替换为高斯噪声; ckpt 自动追加 _noise 后缀.
    """
    print("\n" + "#" * 70)
    print("# Stage 3: Train FusionClassifier  [CTX = GAUSSIAN NOISE ABLATION]")
    print("#" * 70)
    _setup_seed(cfg.data.seed)
    cfg.ensure_dirs()

    save_path = _noise_ckpt_path(cfg.mm_ckpt_path)
    print(f"[CKPT ] {save_path}  (noise ablation)")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # ---- 训练 ----
    if cfg.runtime.code_state in ("only_train", "train_test"):
        d_tr = _load_cache(cfg.cache_paths["train"])
        d_val = _load_cache(cfg.cache_paths["val"])
        d_tr = _replace_ctx_with_noise(d_tr, cfg.data.seed, "train")
        d_val = _replace_ctx_with_noise(d_val, cfg.data.seed, "val")
        print(f"Train: x={d_tr['x'].shape}, ctx={d_tr['ctx_vec'].shape}")
        print(f"Val  : x={d_val['x'].shape}, ctx={d_val['ctx_vec'].shape}")
        d_ctx = d_tr["ctx_vec"].shape[1]

        train_loader = _make_loader(d_tr, cfg.fusion.batch_size, shuffle=True)
        val_loader = _make_loader(d_val, cfg.fusion.batch_size, shuffle=False)

        model = _build_model(cfg, d_ctx=d_ctx).to(device)
        n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"[Model] FusionClassifier trainable params: {n_train:,}, "
              f"fusion={cfg.fusion.fusion}")

        optimizer = torch.optim.Adam(model.parameters(), lr=cfg.fusion.lr,
                                     weight_decay=cfg.fusion.wd)
        criterion = nn.CrossEntropyLoss().to(device)
        scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.1,
                                      patience=cfg.fusion.scheduler_patience,
                                      min_lr=cfg.fusion.min_lr)

        best_val = float('inf')
        no_improve = 0
        for epoch in range(1, cfg.fusion.epochs + 1):
            _train_epoch(model, criterion, train_loader, optimizer, epoch, device,
                         cfg.fusion.grad_clip)
            val_loss, _ = _eval_epoch(model, criterion, val_loader, epoch, device)
            scheduler.step(val_loss)
            if val_loss < best_val:
                print(f"Validation loss improved {best_val:.6f} -> {val_loss:.6f}. Saving...")
                best_val = val_loss
                torch.save(model.state_dict(), save_path)
                no_improve = 0
            else:
                no_improve += 1
                print(f"No improvement for {no_improve} epoch(s).")
            if no_improve >= cfg.fusion.patience_early_stop:
                print(f"Early stopping at epoch {epoch}.")
                break
            print("-" * 50)

    # ---- 测试 ----
    if cfg.runtime.code_state in ("only_test", "train_test"):
        if not save_path.exists():
            raise FileNotFoundError(f"Checkpoint 不存在: {save_path}")
        d_te = _load_cache(cfg.cache_paths["test"])
        d_te = _replace_ctx_with_noise(d_te, cfg.data.seed, "test")
        print(f"Test : x={d_te['x'].shape}, ctx={d_te['ctx_vec'].shape}")
        d_ctx = d_te["ctx_vec"].shape[1]

        model = _build_model(cfg, d_ctx=d_ctx)
        state = torch.load(save_path, map_location="cpu")
        model.load_state_dict(state)
        model = model.to(device)

        test_loader = _make_loader(d_te, batch_size=128, shuffle=False)
        _test_epoch(model, test_loader, device)

    return save_path


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from config import parse_runtime_args
    cfg = parse_runtime_args(Config())
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.runtime.gpu
    print(cfg.describe())
    run(cfg)