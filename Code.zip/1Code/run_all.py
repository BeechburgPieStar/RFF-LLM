# -*- coding: utf-8 -*-
"""
主入口: 按顺序执行三个 stage.

    Stage 1: 训练 SignalTokenizer (VQ-VAE)
    Stage 2: 用冻结的 VQ-VAE + 冻结的 Qwen 预计算 ctx_vec, 存盘
    Stage 3: 用预计算的 ctx_vec 训练 FusionClassifier

每个 stage 都会自检 "输出文件是否已经存在":
    - VQ-VAE ckpt 存在 -> 跳过 stage 1
    - 三个 .npz 都存在 -> 跳过 stage 2 (除非 --overwrite_cache)
    - FusionClassifier ckpt 存在但 code_state 含 train -> 仍会重训覆盖

命令行参数:
    --gpu 0
    --code_state train_test|only_train|only_test
    --overwrite_cache
    --stage 1|2|3|all
    # 扫参用 (sweep.sh 会传这三个):
    --dataset_name ManySig|ManyRx
    --test_round 0..3
    --llm_hidden <int>

用法:
    python run_all.py                                       # 顺序跑三个 stage
    python run_all.py --stage 3 --code_state only_test
    python run_all.py --gpu 1 --overwrite_cache
    python run_all.py --stage 3 --dataset_name ManyRx --test_round 2 --llm_hidden 16
"""
import argparse
import os

from config import Config


def parse_args():
    parser = argparse.ArgumentParser(description="LLM4RFF 主入口")
    # ---- 运行时 ----
    parser.add_argument('--gpu', type=str, default=None,
                        help="CUDA_VISIBLE_DEVICES (覆盖 config.RuntimeConfig.gpu)")
    parser.add_argument('--code_state', type=str, default=None,
                        choices=["only_train", "only_test", "train_test"],
                        help="stage 3 的训练/测试模式")
    parser.add_argument('--overwrite_cache', action='store_true', default=False,
                        help="stage 2 强制重算 ctx_vec 缓存")
    parser.add_argument('--stage', type=str, default="all",
                        choices=["1", "2", "3", "all"],
                        help="只跑指定 stage, 默认 all (顺序跑 1 -> 2 -> 3)")

    # ---- 扫参 (覆盖 config 的对应字段) ----
    parser.add_argument('--dataset_name', type=str, default=None,
                        choices=["ManySig", "ManyRx"],
                        help="覆盖 DataConfig.dataset_name")
    parser.add_argument('--test_round', type=int, default=None,
                        help="覆盖 DataConfig.test_round (0..all_test_round-1)")
    parser.add_argument('--llm_hidden', type=int, default=None,
                        help="覆盖 FusionConfig.llm_hidden")

    return parser.parse_args()


def main():
    args = parse_args()

    # 1) 构造 Config, 用命令行覆盖
    cfg = Config()
    # 运行时
    if args.gpu is not None:
        cfg.runtime.gpu = args.gpu
    if args.code_state is not None:
        cfg.runtime.code_state = args.code_state
    cfg.runtime.overwrite_cache = args.overwrite_cache
    # 扫参
    if args.dataset_name is not None:
        cfg.data.dataset_name = args.dataset_name
    if args.test_round is not None:
        cfg.data.test_round = args.test_round
    if args.llm_hidden is not None:
        cfg.fusion.llm_hidden = args.llm_hidden

    # 2) GPU 必须在 import torch 之前设置
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.runtime.gpu

    # 3) 打印配置, 留作日志
    print(cfg.describe())

    # 4) 按 stage 调度 (此处再 import, 确保 CUDA_VISIBLE_DEVICES 已生效)
    from stages import train_vqvae, precompute_ctx, train_fusion

    if args.stage in ("1", "all"):
        train_vqvae.run(cfg)

    if args.stage in ("2", "all"):
        precompute_ctx.run(cfg)

    if args.stage in ("3", "all"):
        train_fusion.run(cfg)

    print("\n[All Done]")


if __name__ == "__main__":
    main()