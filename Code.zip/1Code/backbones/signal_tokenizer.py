# -*- coding: utf-8 -*-
"""
SignalTokenizer (VQ-VAE for RF I/Q signals).

Encoder: Conv1d patchify (与 PatchEmbed1D 对齐) + 可选 ResBlock
Decoder: ConvTranspose1d 反 patchify, 重叠区域用 ones-decoder 归一化

输入/输出形状: (B, 2, L)
"""
from typing import Dict
import torch
import torch.nn as nn
import torch.nn.functional as F

from .vector_quantizer import VectorQuantizerEMA


# ---------------------------------------------------------------------------
class ResBlock1D(nn.Module):
    """轻量残差块, 给 encoder/decoder 增加非线性容量."""
    def __init__(self, channels: int, hidden: int = None):
        super().__init__()
        hidden = hidden or channels
        self.net = nn.Sequential(
            nn.Conv1d(channels, hidden, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv1d(hidden, channels, kernel_size=1),
        )

    def forward(self, x):
        return x + self.net(x)


# ---------------------------------------------------------------------------
class Encoder1D(nn.Module):
    """
    (B, 2, L) -> (B, N, d_code)
    patchify (Conv1d, stride=patch_size//2) 然后过若干 ResBlock.
    """
    def __init__(self, in_chans: int = 2, d_code: int = 64,
                 patch_size: int = 64, n_resblocks: int = 2):
        super().__init__()
        self.patch_size = patch_size
        self.stride = max(1, patch_size // 2)

        self.patchify = nn.Conv1d(in_chans, d_code,
                                  kernel_size=patch_size, stride=self.stride)
        self.blocks = nn.Sequential(*[ResBlock1D(d_code) for _ in range(n_resblocks)])
        self.norm = nn.LayerNorm(d_code)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 2, L) -> (B, d_code, N)
        z = self.patchify(x)
        z = self.blocks(z)
        z = z.transpose(1, 2)            # (B, N, d_code)
        z = self.norm(z)
        return z


# ---------------------------------------------------------------------------
class Decoder1D(nn.Module):
    """
    (B, N, d_code) -> (B, 2, L_out)
    使用 ConvTranspose1d, kernel/stride 与 encoder 镜像.
    重叠区域天然会累加, 用一个 ones ConvTranspose 算同分母做归一化.
    """
    def __init__(self, out_chans: int = 2, d_code: int = 64,
                 patch_size: int = 64, n_resblocks: int = 2):
        super().__init__()
        self.patch_size = patch_size
        self.stride = max(1, patch_size // 2)

        self.blocks = nn.Sequential(*[ResBlock1D(d_code) for _ in range(n_resblocks)])
        self.deconv = nn.ConvTranspose1d(
            d_code, out_chans,
            kernel_size=patch_size, stride=self.stride,
        )

    def forward(self, z_q: torch.Tensor, target_len: int = None) -> torch.Tensor:
        """
        z_q: (B, N, d_code)
        target_len: 期望输出长度, 若不为 None 则裁/补到该长度
        """
        z = z_q.transpose(1, 2)          # (B, d_code, N)
        z = self.blocks(z)
        out = self.deconv(z)             # (B, 2, L_recon)

        # 归一化重叠累加: 用全 1 输入做一次同样的 conv_transpose
        N = z_q.size(1)
        ones = torch.ones(1, self.deconv.in_channels, N,
                          device=z_q.device, dtype=z_q.dtype)
        norm = F.conv_transpose1d(
            ones,
            torch.ones_like(self.deconv.weight),
            stride=self.stride,
        )                                # (1, out_chans, L_recon)
        out = out / norm.clamp(min=1e-6)

        if target_len is not None and out.size(-1) != target_len:
            out = out[..., :target_len]
        return out


# ---------------------------------------------------------------------------
class SignalTokenizer(nn.Module):
    """VQ-VAE: 把 (B, 2, L) 的 I/Q 信号离散成 token 序列."""

    def __init__(
        self,
        signal_len: int = 256,
        patch_size: int = 64,
        d_code: int = 64,
        codebook_size: int = 512,
        n_resblocks: int = 2,
        commitment_cost: float = 0.25,
        ema_decay: float = 0.99,
    ):
        super().__init__()
        self.signal_len = signal_len
        self.encoder = Encoder1D(in_chans=2, d_code=d_code,
                                 patch_size=patch_size, n_resblocks=n_resblocks)
        self.vq = VectorQuantizerEMA(
            num_embeddings=codebook_size,
            embedding_dim=d_code,
            commitment_cost=commitment_cost,
            decay=ema_decay,
        )
        self.decoder = Decoder1D(out_chans=2, d_code=d_code,
                                 patch_size=patch_size, n_resblocks=n_resblocks)

    # ------------------------------------------------------------------
    def encode_tokens(self, x: torch.Tensor) -> torch.Tensor:
        """无梯度推理接口: x (B,2,L) -> token_ids (B, N)."""
        self.eval()
        with torch.no_grad():
            z_e = self.encoder(x)
            _, token_ids, _ = self.vq(z_e)
        return token_ids

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        z_e = self.encoder(x)                                  # (B, N, D)
        z_q, token_ids, vq_stats = self.vq(z_e)                # (B, N, D), (B, N)

        x_recon = self.decoder(z_q, target_len=x.size(-1))     # (B, 2, L)

        recon_loss = F.mse_loss(x_recon, x)
        total_loss = recon_loss + self.vq.beta * vq_stats["commit_loss"]

        return {
            "x_recon": x_recon,
            "token_ids": token_ids,
            "loss": total_loss,
            "recon_loss": recon_loss,
            "commit_loss": vq_stats["commit_loss"],
            "perplexity": vq_stats["perplexity"],
            "unique_tokens": vq_stats["unique_tokens"],
            "codebook_util": vq_stats["codebook_util"],
        }

    # ------------------------------------------------------------------
    def restart_dead_codes(self, x: torch.Tensor):
        """训练循环里偶尔调用 (例如每 N 个 step)."""
        with torch.no_grad():
            z_e = self.encoder(x)
            flat_z = z_e.reshape(-1, z_e.size(-1))
        return self.vq.restart_dead_codes(flat_z)
