# -*- coding: utf-8 -*-
"""
FusionClassifier: 多模态分类器 (训练阶段唯一有梯度的模块).

- IQ 分支: PatchNet 结构 (PatchEmbed1D + MLPBlock x n), 输出 feat_iq (B, embed_dim)
- LLM 分支: 预计算的 ctx_vec (B, d_ctx) 过投影头得到 feat_llm (B, d_fuse)
- 融合: concat 或 gated, 输出 feat_fused (B, d_fuse)

调用接口:
    model = FusionClassifier(d_ctx=1024, num_classes=6, ...)
    feat, logits = model(x, ctx_vec)
"""
from typing import Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
class PatchEmbed1D(nn.Module):
    def __init__(self, in_chans: int = 2, embed_dim: int = 128, patch_size: int = 64):
        super().__init__()
        stride = max(1, patch_size // 2)
        self.proj = nn.Conv1d(in_chans, embed_dim, kernel_size=patch_size, stride=stride)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 2, L) -> (B, embed_dim, N) -> (B, N, embed_dim)
        return self.proj(x).transpose(1, 2)


class MLPBlock(nn.Module):
    """Pre-LN MLP + 残差."""
    def __init__(self, dim: int, mlp_ratio: float = 2.0, dropout: float = 0.0):
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.norm = nn.LayerNorm(dim)
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.fc1(self.norm(x))
        h = F.gelu(h)
        h = self.drop(h)
        h = self.fc2(h)
        return x + self.drop(h)


# ---------------------------------------------------------------------------
class IQBranch(nn.Module):
    """信号分支: PatchNet 结构, 输出特征向量."""
    def __init__(
        self,
        patch_size: int = 64,
        embed_dim: int = 128,
        n_layers: int = 1,
        mlp_ratio: float = 2.0,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.patch_embed = PatchEmbed1D(in_chans=2, embed_dim=embed_dim,
                                        patch_size=patch_size)
        self.blocks = nn.ModuleList([
            MLPBlock(embed_dim, mlp_ratio=mlp_ratio, dropout=dropout)
            for _ in range(n_layers)
        ])
        self.norm = nn.LayerNorm(embed_dim)
        self.out_dim = embed_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = self.patch_embed(x)        # (B, N, embed_dim)
        for blk in self.blocks:
            tokens = blk(tokens)
        tokens = self.norm(tokens)
        feat = tokens.mean(dim=1)           # GAP -> (B, embed_dim)
        return feat


# ---------------------------------------------------------------------------
class LLMBranch(nn.Module):
    """LLM 分支: ctx_vec -> 投影到 d_fuse."""
    def __init__(self, d_ctx: int, d_fuse: int, hidden: int = 256, dropout: float = 0.0):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(d_ctx),
            nn.Linear(d_ctx, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, d_fuse),
        )
        self.out_dim = d_fuse

    def forward(self, ctx_vec: torch.Tensor) -> torch.Tensor:
        return self.net(ctx_vec)


# ---------------------------------------------------------------------------
class ConcatFusion(nn.Module):
    """[proj(iq) | llm] -> LN -> Linear -> GELU."""
    def __init__(self, d_iq: int, d_llm: int, d_fuse: int, dropout: float = 0.0):
        super().__init__()
        self.iq_proj = nn.Linear(d_iq, d_fuse)
        self.net = nn.Sequential(
            nn.LayerNorm(2 * d_fuse),
            nn.Linear(2 * d_fuse, d_fuse),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.out_dim = d_fuse

    def forward(self, feat_iq: torch.Tensor, feat_llm: torch.Tensor) -> torch.Tensor:
        a = self.iq_proj(feat_iq)                # (B, d_fuse)
        h = torch.cat([a, feat_llm], dim=-1)     # (B, 2*d_fuse)
        return self.net(h)                       # (B, d_fuse)


class GatedFusion(nn.Module):
    """学习门控 g, fused = g * proj(iq) + (1-g) * llm."""
    def __init__(self, d_iq: int, d_llm: int, d_fuse: int, dropout: float = 0.0):
        super().__init__()
        self.iq_proj = nn.Linear(d_iq, d_fuse)
        self.gate = nn.Sequential(
            nn.Linear(2 * d_fuse, d_fuse),
            nn.Sigmoid(),
        )
        self.post = nn.Sequential(
            nn.LayerNorm(d_fuse),
            nn.Dropout(dropout),
        )
        self.out_dim = d_fuse

    def forward(self, feat_iq: torch.Tensor, feat_llm: torch.Tensor) -> torch.Tensor:
        a = self.iq_proj(feat_iq)
        g = self.gate(torch.cat([a, feat_llm], dim=-1))   # (B, d_fuse), 0..1
        fused = g * a + (1.0 - g) * feat_llm
        return self.post(fused)


# ---------------------------------------------------------------------------
class FusionClassifier(nn.Module):
    """多模态分类器: IQ 分支 + LLM 分支 -> 融合 -> 分类头."""

    def __init__(
        self,
        d_ctx: int,                  # LLM ctx_vec 维度 (Qwen3-Embedding-0.6B = 1024)
        num_classes: int = 6,
        iq_patch_size: int = 64,
        embed_dim: int = 128,
        n_layers: int = 1,
        mlp_ratio: float = 2.0,
        d_fuse: int = 128,
        llm_hidden: int = 256,
        fusion: str = "concat",
        dropout: float = 0.0,
    ):
        super().__init__()
        self.iq_branch = IQBranch(
            patch_size=iq_patch_size, embed_dim=embed_dim,
            n_layers=n_layers, mlp_ratio=mlp_ratio, dropout=dropout,
        )
        self.llm_branch = LLMBranch(
            d_ctx=d_ctx, d_fuse=d_fuse, hidden=llm_hidden, dropout=dropout,
        )

        if fusion == "concat":
            self.fusion = ConcatFusion(
                d_iq=self.iq_branch.out_dim, d_llm=self.llm_branch.out_dim,
                d_fuse=d_fuse, dropout=dropout,
            )
        elif fusion == "gated":
            self.fusion = GatedFusion(
                d_iq=self.iq_branch.out_dim, d_llm=self.llm_branch.out_dim,
                d_fuse=d_fuse, dropout=dropout,
            )
        else:
            raise ValueError(f"unknown fusion: {fusion}")

        self.cls_head = nn.Linear(self.fusion.out_dim, num_classes)

    def forward(self, x: torch.Tensor, ctx_vec: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        x:       (B, 2, L)
        ctx_vec: (B, d_ctx)
        return:  (feat_fused, logits)
        """
        feat_iq = self.iq_branch(x)             # (B, embed_dim)
        feat_llm = self.llm_branch(ctx_vec)     # (B, d_fuse)
        feat = self.fusion(feat_iq, feat_llm)   # (B, d_fuse)
        logits = self.cls_head(feat)
        return feat, logits
