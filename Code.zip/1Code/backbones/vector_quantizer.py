# -*- coding: utf-8 -*-
"""
Vector Quantizer with EMA updates and dead-code restart.

参考: van den Oord et al. 2017 (VQ-VAE), Razavi et al. 2019 (VQ-VAE-2)
"""
from typing import Tuple, Dict
import torch
import torch.nn as nn
import torch.nn.functional as F


class VectorQuantizerEMA(nn.Module):
    """
    输入:   z_e (B, N, D)        # 连续 encoder 输出
    输出:   z_q (B, N, D)        # 量化后, 直通梯度
            token_ids (B, N)     # 离散索引
            stats: dict          # 监控指标
    """
    def __init__(
        self,
        num_embeddings: int = 512,
        embedding_dim: int = 64,
        commitment_cost: float = 0.25,
        decay: float = 0.99,
        eps: float = 1e-5,
        dead_code_threshold: int = 2,  # 计数小于此值的码字视为"死"
    ):
        super().__init__()
        self.K = num_embeddings
        self.D = embedding_dim
        self.beta = commitment_cost
        self.decay = decay
        self.eps = eps
        self.dead_threshold = dead_code_threshold

        # 码本: (K, D), 初始化用 Xavier
        embed = torch.empty(num_embeddings, embedding_dim)
        nn.init.uniform_(embed, -1.0 / num_embeddings, 1.0 / num_embeddings)

        # EMA buffer
        self.register_buffer("embedding", embed)                           # (K, D)
        self.register_buffer("ema_cluster_size", torch.zeros(num_embeddings))
        self.register_buffer("ema_embedding_sum", embed.clone())           # (K, D)
        # 用于死码统计 (跨 batch 累积)
        self.register_buffer("usage_count", torch.zeros(num_embeddings, dtype=torch.long))

    # ------------------------------------------------------------------
    def _quantize(self, flat_z: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        flat_z: (M, D)
        return: token_ids (M,), z_q (M, D)
        """
        # ||z - e||^2 = ||z||^2 - 2 z·e + ||e||^2
        z_sq = (flat_z ** 2).sum(dim=1, keepdim=True)            # (M, 1)
        e_sq = (self.embedding ** 2).sum(dim=1)                  # (K,)
        ze = flat_z @ self.embedding.t()                         # (M, K)
        dist = z_sq + e_sq.unsqueeze(0) - 2 * ze                 # (M, K)

        token_ids = dist.argmin(dim=1)                           # (M,)
        z_q = self.embedding[token_ids]                          # (M, D)
        return token_ids, z_q

    # ------------------------------------------------------------------
    @torch.no_grad()
    def _ema_update(self, flat_z: torch.Tensor, token_ids: torch.Tensor):
        """EMA 更新码字 (只在训练时调用)."""
        encodings = F.one_hot(token_ids, num_classes=self.K).type(flat_z.dtype)

        # 1) 更新 cluster size
        cluster_size_new = encodings.sum(dim=0)                  # (K,)
        self.ema_cluster_size.mul_(self.decay).add_(cluster_size_new, alpha=1 - self.decay)

        # 2) 更新 embedding sum
        dw = encodings.t() @ flat_z                              # (K, D)
        self.ema_embedding_sum.mul_(self.decay).add_(dw, alpha=1 - self.decay)

        # 3) Laplace 平滑后, 更新码字
        n = self.ema_cluster_size.sum()
        cluster_size_smoothed = (self.ema_cluster_size + self.eps) / (n + self.K * self.eps) * n
        self.embedding.copy_(self.ema_embedding_sum / cluster_size_smoothed.unsqueeze(1))

        # 4) 累计使用计数 (用于死码统计)
        self.usage_count += cluster_size_new.long()

    # ------------------------------------------------------------------
    @torch.no_grad()
    def restart_dead_codes(self, flat_z: torch.Tensor):
        """
        死码重启: 把使用计数小于阈值的码字, 用当前 batch 的随机 z_e 替换.
        flat_z: (M, D), M 必须 >= 死码数, 否则随机重复采样.
        """
        dead_mask = self.usage_count < self.dead_threshold       # (K,) bool
        n_dead = int(dead_mask.sum().item())
        if n_dead == 0:
            return 0

        M = flat_z.size(0)
        idx = torch.randint(0, M, (n_dead,), device=flat_z.device)
        new_codes = flat_z[idx]                                  # (n_dead, D)

        self.embedding[dead_mask] = new_codes
        # 同步重置 EMA 状态, 否则新码会被旧 EMA 拖回
        self.ema_embedding_sum[dead_mask] = new_codes
        self.ema_cluster_size[dead_mask] = 1.0
        self.usage_count.zero_()                                 # 全表重新累计
        return n_dead

    # ------------------------------------------------------------------
    def forward(self, z_e: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """
        z_e: (B, N, D)
        """
        B, N, D = z_e.shape
        assert D == self.D, f"维度不匹配: 输入 {D}, 码本 {self.D}"

        flat_z = z_e.reshape(-1, D)                              # (B*N, D)
        token_ids, z_q_flat = self._quantize(flat_z)

        if self.training:
            self._ema_update(flat_z.detach(), token_ids)

        # commitment loss (只让 encoder 输出向当前码字靠拢, 码字本身由 EMA 更新)
        commit_loss = F.mse_loss(flat_z, z_q_flat.detach())

        # Straight-through: 反向时 z_q 的梯度直接传给 z_e
        z_q_flat = flat_z + (z_q_flat - flat_z).detach()

        z_q = z_q_flat.view(B, N, D)
        token_ids = token_ids.view(B, N)

        # 监控指标
        with torch.no_grad():
            encodings = F.one_hot(token_ids.reshape(-1), num_classes=self.K).float()
            avg_probs = encodings.mean(dim=0)                    # (K,)
            perplexity = torch.exp(-torch.sum(avg_probs * torch.log(avg_probs + 1e-10)))
            unique_per_batch = int(token_ids.unique().numel())

        stats = {
            "commit_loss": commit_loss,
            "perplexity": perplexity.item(),
            "unique_tokens": unique_per_batch,
            "codebook_util": unique_per_batch / self.K,
        }
        return z_q, token_ids, stats
