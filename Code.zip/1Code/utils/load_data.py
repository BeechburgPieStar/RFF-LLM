# -*- coding: utf-8 -*-
"""
加载 ManySig / ManyRx 数据集.

文件路径约定:
    <dataset_root>/<dataset_name>/<is_eq>/date<date_index>/rx_<rx_id>_data.pkl
"""
import os
import pickle
import numpy as np


# 各数据集对应的接收机索引
rx_indexes_of_manysig = [
    '1-1', '1-19', '2-1', '2-19', '3-19', '7-7', '7-14',
    '8-8', '14-7', '18-2', '19-2', '20-1'
]

rx_indexes_of_manyrx = [
    '1-1', '1-19', '1-20', '2-1', '2-19', '3-19',
    '7-7', '7-14', '8-7', '8-8', '8-14',
    '13-7', '13-14', '14-7',
    '18-2', '18-19',
    '19-1', '19-2', '19-19', '19-20',
    '20-1', '20-19', '20-20',
    '23-1', '23-3', '23-5', '23-6', '23-7',
    '24-5', '24-6', '24-13', '24-16'
]


def preprocessing(x: np.ndarray) -> np.ndarray:
    """对输入数据进行归一化, 使每条样本的平均功率为 1."""
    for i in range(x.shape[0]):
        power = np.sum(x[i, 0, :] ** 2 + x[i, 1, :] ** 2) / x.shape[2]
        x[i] = x[i] / np.sqrt(power)
    return x


def load_single_dataset(
    dataset: str,
    rx_index: int,
    date_index: int,
    tx_num: int,
    is_eq: str = 'non_equalized',
    dataset_root: str = "dataset",
):
    """
    加载单个 Rx/日期的数据, 提取每个 Tx 的前 100 个样本并标准化.
    返回:
        x: (N_total, 2, L)  功率归一化后的 I/Q
        y: (N_total,)       Tx 索引
    """
    if dataset == 'ManySig':
        rx_indexes = rx_indexes_of_manysig
    elif dataset == 'ManyRx':
        rx_indexes = rx_indexes_of_manyrx
    else:
        raise ValueError(f"Unknown dataset: {dataset}")

    folder_path = os.path.join(dataset_root, dataset, is_eq)
    file_path = os.path.join(folder_path, f'date{date_index}',
                             f'rx_{rx_indexes[rx_index]}_data.pkl')

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Data file not found at path: {file_path}")
    with open(file_path, 'rb') as f:
        data = pickle.load(f)

    x_list, y_list = [], []
    for tx_index in range(tx_num):
        tx_data = data['data'][tx_index]                            # (N, L, 2)
        tx_data_formatted = np.transpose(tx_data, (0, 2, 1))[:100]  # (100, 2, L)
        x_list.append(tx_data_formatted)
        y_list.extend([tx_index] * tx_data_formatted.shape[0])

    x = np.concatenate(x_list, axis=0)
    x = preprocessing(x)
    y = np.array(y_list)
    return x, y
