# -*- coding: utf-8 -*-
"""
ContextEncoder: 全冻结地构造每条样本的 ctx_vec, 用于离线预计算.

    x (B, 2, L) + rx_id
      -> SignalTokenizer.encode_tokens (冻结) -> token_ids (B, N_vq)
      -> 固定映射 vq_id -> qwen_id  (base_offset, 无可学参数)
      -> Qwen 原生词嵌入 (冻结) -> vq_token_embeds (B, N_vq, d_llm)
      -> [prompt_prefix_embeds(rx_id) | vq_token_embeds]
      -> 冻结 Qwen 主干
      -> last/mean pool -> ctx_vec (B, d_llm)

唯一冻结源: SignalTokenizer 权重 + Qwen 权重. 无任何可学习参数.
"""
from typing import Optional, List
import torch
import torch.nn as nn

from transformers import AutoModel, AutoTokenizer


class ContextEncoder(nn.Module):
    def __init__(
        self,
        tokenizer_model,                          # SignalTokenizer, 已加载预训练权重
        llm_path: str,
        num_rx: int,
        codebook_size: int,
        vq_qwen_base_offset: int = 1000,
        prompt_template: Optional[str] = None,
        pool: str = "last",
        torch_dtype: torch.dtype = torch.float32,
    ):
        super().__init__()
        self.pool = pool
        self.num_rx = num_rx
        self.codebook_size = codebook_size
        self.vq_qwen_base_offset = vq_qwen_base_offset

        # ---- 1. 冻结 SignalTokenizer ----
        self.tokenizer_model = tokenizer_model
        for p in self.tokenizer_model.parameters():
            p.requires_grad = False
        self.tokenizer_model.eval()

        # ---- 2. 加载并冻结 Qwen ----
        self.llm = AutoModel.from_pretrained(
            llm_path, trust_remote_code=True, torch_dtype=torch_dtype,
        )
        for p in self.llm.parameters():
            p.requires_grad = False
        self.llm.eval()

        d_llm = self.llm.config.hidden_size
        self.d_llm = d_llm

        # ---- 3. 检查 base_offset 合法 ----
        V = self.llm.get_input_embeddings().num_embeddings
        if vq_qwen_base_offset + codebook_size > V:
            raise ValueError(
                f"base_offset({vq_qwen_base_offset}) + codebook_size({codebook_size}) "
                f"= {vq_qwen_base_offset + codebook_size} 超出 Qwen 词表大小 {V}"
            )

        # ---- 4. Tokenizer + 按 rx_id 预生成 prompt prefix ----
        self.text_tokenizer = AutoTokenizer.from_pretrained(llm_path, trust_remote_code=True)
        word_emb = self.llm.get_input_embeddings().weight.detach()
        self.register_buffer("_word_emb_ref", word_emb, persistent=False)

        if prompt_template is None:
            prompt_template = (
                "The following is the discrete token codes of non-equalized I/Q samples "
                "received by receiver {rx_id}. These tokens encode hardware fingerprint "
                "patterns of the transmitter. Token sequence:"
            )
        self.prompt_template = prompt_template

        pad_id = self.text_tokenizer.pad_token_id
        if pad_id is None:
            pad_id = self.text_tokenizer.eos_token_id

        prefix_ids_list: List[torch.Tensor] = []
        for rx_id in range(num_rx):
            text = prompt_template.format(rx_id=rx_id)
            ids = self.text_tokenizer(text, return_tensors="pt",
                                      add_special_tokens=False).input_ids[0]
            prefix_ids_list.append(ids)

        max_len = max(len(ids) for ids in prefix_ids_list)
        padded = torch.full((num_rx, max_len), pad_id, dtype=torch.long)
        prefix_mask = torch.zeros((num_rx, max_len), dtype=torch.long)
        for i, ids in enumerate(prefix_ids_list):
            # 左 pad: 真实文本对齐到序列末尾
            padded[i, max_len - len(ids):] = ids
            prefix_mask[i, max_len - len(ids):] = 1

        prefix_embeds = word_emb[padded].clone()                  # (num_rx, max_len, d_llm)
        self.register_buffer("prefix_embeds_table", prefix_embeds)
        self.register_buffer("prefix_mask_table", prefix_mask)
        self.prefix_len = max_len

    # ------------------------------------------------------------------
    def train(self, mode: bool = True):
        """无论外面怎么切, 内部 LLM/Tokenizer 永远 eval()."""
        super().train(mode)
        self.tokenizer_model.eval()
        self.llm.eval()
        return self

    # ------------------------------------------------------------------
    def _pool(self, hidden: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
        if self.pool == "mean":
            mask = attn_mask.unsqueeze(-1).float()
            return (hidden * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1.0)
        # last pool: 取最后一个有效 token 的 hidden state
        lengths = attn_mask.sum(dim=1) - 1
        idx = lengths.view(-1, 1, 1).expand(-1, 1, hidden.size(-1))
        return hidden.gather(dim=1, index=idx).squeeze(1)

    # ------------------------------------------------------------------
    @torch.no_grad()
    def forward(self, x: torch.Tensor, rx_ids: torch.Tensor) -> torch.Tensor:
        """
        x:      (B, 2, L)
        rx_ids: (B,)
        return: ctx_vec (B, d_llm)
        """
        B = x.size(0)

        # 1) VQ encode
        token_ids = self.tokenizer_model.encode_tokens(x)        # (B, N_vq)
        N_vq = token_ids.size(1)

        # 2) vq_id -> qwen_id (固定映射)
        qwen_token_ids = token_ids + self.vq_qwen_base_offset    # (B, N_vq) long
        vq_token_embeds = self._word_emb_ref[qwen_token_ids]     # (B, N_vq, d_llm)

        # 3) rx prefix
        prefix_embeds = self.prefix_embeds_table[rx_ids]         # (B, P, d_llm)
        prefix_mask = self.prefix_mask_table[rx_ids]             # (B, P)

        # 4) 拼接
        inputs_embeds = torch.cat([prefix_embeds, vq_token_embeds], dim=1)
        vq_mask = torch.ones(B, N_vq, dtype=torch.long, device=x.device)
        attn_mask = torch.cat([prefix_mask, vq_mask], dim=1)

        # 5) Qwen
        llm_out = self.llm(
            inputs_embeds=inputs_embeds,
            attention_mask=attn_mask,
            output_hidden_states=False,
            return_dict=True,
        )
        hidden = llm_out.last_hidden_state                       # (B, P+N_vq, d_llm)
        return self._pool(hidden, attn_mask)                     # (B, d_llm)
