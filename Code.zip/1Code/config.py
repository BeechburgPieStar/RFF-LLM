# -*- coding: utf-8 -*-
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Literal, Dict, Optional

@dataclass
class DataConfig:
    """数据集与划分协议."""

    # 数据集名: ManySig (6 Tx, 12 Rx) 或 ManyRx (10 Tx, 32 Rx)
    dataset_name: Literal["ManySig", "ManyRx"] = "ManyRx"

    # 实验协议:
    #   CR  = Cross-Receiver:        训练/测试同日期, 跨接收机
    #   CRD = Cross-Receiver-Date:   训练/测试既跨接收机也跨日期 (更难)
    exp: Literal["CR", "CRD"] = "CRD"

    # 训练使用的采集日期 (date 索引列表)
    train_date: List[int] = field(default_factory=lambda: [1, 2])

    # 测试使用的采集日期:
    #   None  -> CR  时自动取 train_date
    #           CRD 时自动取 all_dates \ train_date
    #   非空  -> 直接使用该列表
    test_date: Optional[List[int]] = None

    # 数据集中全部可用的日期, 用于 CRD 自动推断 test_date
    all_dates: List[int] = field(default_factory=lambda: [1, 2, 3, 4])

    # 接收机 K-fold 折数
    all_test_round: int = 4

    # 当前是第几折 (取值范围: 0 .. all_test_round - 1)
    test_round: int = 3

    # 全局随机种子 (numpy/torch/random, 同时用于 train/val 划分)
    seed: int = 2023


@dataclass
class VQVAEConfig:
    """VQ-VAE 信号 tokenizer (阶段 1: 离线预训练)."""

    # ---- 模型结构 ----
    # 1D patch 长度 (Conv1d kernel_size), encoder/decoder 共用
    patch_size: int = 64
    # 码字维度 D
    d_code: int = 64
    # 码本大小 K
    codebook_size: int = 128
    # encoder/decoder 各自的 ResBlock 数量
    n_resblocks: int = 2
    # commitment loss 系数 β (encoder 向码字靠拢的权重)
    commitment_cost: float = 0.25
    # 码本 EMA 衰减系数
    ema_decay: float = 0.99

    # ---- 训练超参 ----
    batch_size: int = 128
    epochs: int = 200
    lr: float = 1e-3
    wd: float = 0.0
    grad_clip: float = None
    patience_early_stop: int = 10
    scheduler_patience: int = 5
    min_lr: float = 1e-6

    # ---- 死码重启 ----
    # 每多少 step 重启一次低使用率的码字; 0 表示关闭
    restart_every: int = 500
    # 前多少 step 不做死码重启 (让码本先稳定下来)
    warmup_steps_no_restart: int = 500


@dataclass
class LLMConfig:
    """LLM 上下文编码 (阶段 2: 离线预计算 ctx_vec)."""

    # LLM 权重目录 (本地路径或 huggingface 名)
    llm_path: str = "LLM/Qwen3-Embedding-0.6B"

    # 序列池化方式:
    #   last = 取最后一个有效 token 的 hidden state (left-pad 友好)
    #   mean = attention_mask 加权平均
    pool: Literal["last", "mean"] = "last"

    # VQ id -> Qwen 词表 id 的固定偏移:
    #   qwen_id = vq_id + base_offset
    # 偏移到 1000 避开词表低位的特殊 token (BOS/EOS/PAD 等)
    vq_qwen_base_offset: int = 1000

    # 加载 Qwen 的 dtype (ctx_vec 存盘时一律转 float32)
    llm_dtype: Literal["float32", "float16", "bfloat16"] = "float32"

    # 预计算 ctx_vec 时的 batch size (受 Qwen 显存限制, 通常比训练小)
    ctx_batch_size: int = 64


@dataclass
class FusionConfig:
    """多模态分类器 (阶段 3: 唯一有梯度的模块)."""

    # ---- IQ 分支 (PatchNet) ----
    # 注意: 这是 PatchNet 的 patch_size, 与 VQ-VAE 的 patch_size 互相独立
    iq_patch_size: int = 64
    # IQ 分支 token 维度
    embed_dim: int = 128
    # MLPBlock 层数
    n_layers: int = 1
    # MLPBlock 内部隐层倍率 (hidden = embed_dim * mlp_ratio)
    mlp_ratio: float = 2.0

    # ---- LLM 分支 ----
    # ctx_vec 投影到 d_fuse 的中间层维度
    llm_hidden: int = 16

    # ---- 融合 ----
    # 融合后特征维度
    d_fuse: int = 128
    # 融合方式:
    #   concat = [proj(iq) | llm] -> MLP
    #   gated  = g * proj(iq) + (1-g) * llm,  g 由门控网络学出
    fusion: Literal["concat", "gated"] = "concat"
    # Dropout (各分支 / 融合后共用)
    dropout: float = 0.0

    # ---- 训练超参 ----
    batch_size: int = 128
    epochs: int = 200
    lr: float = 1e-3
    wd: float = 0.0
    grad_clip: float = None
    patience_early_stop: int = 10
    scheduler_patience: int = 5
    min_lr: float = 1e-6


@dataclass
class PathConfig:
    """根目录配置 (只配根目录, 具体文件路径由 Config 的 property 推导)."""

    # VQ-VAE checkpoint 保存目录
    weights_vqvae_dir: str = "weights_vqvae"
    # 多模态分类器 checkpoint 保存目录
    weights_mm_dir: str = "weights_mm"
    # ctx_vec .npz 缓存目录
    cache_dir: str = "ctx_cache"
    # 数据集根目录 (load_data.py 期望: dataset_root/<dataset>/non_equalized/dateX/...)
    dataset_root: str = "dataset"


@dataclass
class RuntimeConfig:
    gpu: str = "0"
    code_state: Literal["only_train", "only_test", "train_test"] = "train_test"
    overwrite_cache: bool = False


# ===========================================================================
# 主配置 + 路径推导
# ===========================================================================
@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    vqvae: VQVAEConfig = field(default_factory=VQVAEConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    fusion: FusionConfig = field(default_factory=FusionConfig)
    paths: PathConfig = field(default_factory=PathConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)

    @property
    def tx_num(self) -> int:
        return {"ManySig": 6, "ManyRx": 10}[self.data.dataset_name]

    @property
    def rx_num(self) -> int:
        return {"ManySig": 12, "ManyRx": 32}[self.data.dataset_name]

    @property
    def test_dates(self) -> List[int]:
        if self.data.test_date is not None and len(self.data.test_date) > 0:
            return list(self.data.test_date)
        if self.data.exp == "CR":
            return list(self.data.train_date)
        other = [d for d in self.data.all_dates if d not in self.data.train_date]
        if len(other) == 0:
            raise ValueError(
                f"CRD test_date 为空: all_dates={self.data.all_dates}, "
                f"train_date={self.data.train_date}"
            )
        return other

    @property
    def vqvae_tag(self) -> str:
        """VQ-VAE 阶段的 tag, 进入 ckpt 文件名."""
        dates = "_".join(map(str, self.data.train_date))
        return (
            f"vqvae_{self.data.dataset_name}"
            f"_date{dates}_round{self.data.test_round}_seed{self.data.seed}"
            f"_ps{self.vqvae.patch_size}"
            f"_dc{self.vqvae.d_code}"
            f"_K{self.vqvae.codebook_size}"
        )

    @property
    def cache_tag(self) -> str:
        return (
            f"{self.vqvae_tag}"
            f"_off{self.llm.vq_qwen_base_offset}"
            f"_{self.llm.pool}"
            f"_{self.data.exp}"
        )

    @property
    def mm_tag(self) -> str:
        return (
            f"mm_{self.cache_tag}"
            f"_ips{self.fusion.iq_patch_size}"
            f"_d{self.fusion.embed_dim}"
            f"_nl{self.fusion.n_layers}"
            f"_df{self.fusion.d_fuse}"
            f"_{self.fusion.fusion}"
        )

    @property
    def vqvae_ckpt_path(self) -> Path:
        return Path(self.paths.weights_vqvae_dir) / f"{self.vqvae_tag}.pth"

    @property
    def cache_paths(self) -> Dict[str, Path]:
        base = Path(self.paths.cache_dir)
        return {
            split: base / f"{self.cache_tag}_{split}.npz"
            for split in ("train", "val", "test")
        }

    @property
    def mm_ckpt_path(self) -> Path:
        return Path(self.paths.weights_mm_dir) / f"{self.mm_tag}.pth"

    def ensure_dirs(self) -> None:
        Path(self.paths.weights_vqvae_dir).mkdir(parents=True, exist_ok=True)
        Path(self.paths.weights_mm_dir).mkdir(parents=True, exist_ok=True)
        Path(self.paths.cache_dir).mkdir(parents=True, exist_ok=True)

    def describe(self) -> str:
        lines = [
            "=" * 70,
            f"Dataset    : {self.data.dataset_name} "
            f"(tx_num={self.tx_num}, rx_num={self.rx_num})",
            f"Protocol   : {self.data.exp}, "
            f"train_date={self.data.train_date}, test_date={self.test_dates}, "
            f"round={self.data.test_round}/{self.data.all_test_round}",
            f"Seed       : {self.data.seed}",
            "-" * 70,
            f"vqvae_tag  : {self.vqvae_tag}",
            f"cache_tag  : {self.cache_tag}",
            f"mm_tag     : {self.mm_tag}",
            "-" * 70,
            f"vqvae ckpt : {self.vqvae_ckpt_path}",
            f"cache dir  : {self.paths.cache_dir}/  ({self.cache_tag}_<split>.npz)",
            f"mm ckpt    : {self.mm_ckpt_path}",
            "=" * 70,
        ]
        return "\n".join(lines)


def parse_runtime_args(cfg: Config) -> Config:
    import argparse
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument('--gpu', type=str, default=cfg.runtime.gpu)
    parser.add_argument('--code_state', type=str, default=cfg.runtime.code_state,
                        choices=["only_train", "only_test", "train_test"])
    parser.add_argument('--overwrite_cache', action='store_true',
                        default=cfg.runtime.overwrite_cache)
    args = parser.parse_args()

    cfg.runtime.gpu = args.gpu
    cfg.runtime.code_state = args.code_state
    cfg.runtime.overwrite_cache = args.overwrite_cache
    return cfg

if __name__ == "__main__":
    cfg = Config()
    print(cfg.describe())
